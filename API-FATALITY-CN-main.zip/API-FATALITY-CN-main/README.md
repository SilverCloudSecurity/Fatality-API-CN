# 说明

本次翻译由 苏黎世银云安全 （Silver Cloud Security Ltd.）全权负责，

由于官方文档过于碎片化，且 [JetBrains Writerside](https://lp.jetbrains.com/writerside/) 提供的托管服务不支持搜索功能，故在此进行重写。

官方Telegram [https://t.me/SilverCloudSecurity](https://t.me/SilverCloudSecurity)

行政邮箱  administrative1999@ProtonMail.com

请注意 MD 文件为 透明，公开，您可以选择保存为本地文件阅读，如果您选择删除本说明文件我方将不再披露任何事件报告以及停止对于公益事件的维护。

本文档大部分为人工翻译相关内容，部分内容由 Anthropic 旗下 Claude 3.5 进行辅助翻译，请注意我司非使用官方文档，属于重新撰写了翻译后的开发文档，且MarkDown很多语法执行该工作者并不熟悉，故还望海涵。

我们正在寻求中国境内的社区运营者 如果你有兴趣和能力欢迎通过行政邮箱联系我。

如果我们和官方文档有出入请以官方文档为主。

官方文档链接 Lua.Fatality.win

---
description: 欢迎开始使用 Fatality
---

# Game 模块

**欢迎开始使用 `game` 模块**

_<mark style="color:red;">`game`</mark> <mark style="color:red;"></mark><mark style="color:red;">模块暴露了 Fatality 使用的各种内部服务和全局对象 同时也提供了获取其他所需服务的方法</mark>_



**字段**

* **global\_vars**
  * **类型**: `global_vars_t`
  * **描述**
    * 此服务暴露了游戏中使用的全局变量 包括帧时间 当前服务器时间等
* **engine**
  * **类型**: `cengine_client`
  * **描述**
    * 此服务暴露了引擎客户端 包含常用的引擎相关函数

***

苏黎世银云安全 ©

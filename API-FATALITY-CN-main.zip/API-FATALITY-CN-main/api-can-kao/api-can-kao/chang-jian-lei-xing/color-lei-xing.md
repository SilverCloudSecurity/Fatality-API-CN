---
description: 欢迎开始使用 Fatality
---

# Color 类型

<mark style="color:blue;">`color`</mark> <mark style="color:blue;"></mark><mark style="color:blue;">类型是在游戏中使用的颜色。</mark>

_<mark style="color:red;">请勿将此类型与用于渲染的颜色混淆！虽然这两种类型在内部是可互换的，但在 API 中它们并不是相同的。</mark>_

***

苏黎世银云安全 ©

---
description: 欢迎使用 Fatality
---

# mods 模块

**欢迎开始使用 `mods` 模块**

_<mark style="color:red;">mods 表暴露了多个 Fatality 使用的模块（Module，非 Modification） 用于操作和扩展功能</mark>_

**字段**

* **events**
  * **类型**: `events_t`
  * **描述**
    * 事件管理器 如果想监听更多游戏内事件 使用此模块

***

苏黎世银云安全 ©

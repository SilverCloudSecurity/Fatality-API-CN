---
description: 欢迎使用 Fatality
---

# cfiring\_mode 类型

**欢迎开始使用 `cfiring_mode` 类型**

<mark style="color:red;">`cfiring_mode`</mark> <mark style="color:red;"></mark><mark style="color:red;">表示射击模式信息</mark>

**字段**

* **values\_arr**
  * **类型**: `<type>`
  * **描述**: 值数组
  * **读取权限**: 只读

***

苏黎世银云安全 ©

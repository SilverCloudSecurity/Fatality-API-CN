---
description: 欢迎使用 Fatality
---

# csweapon\_mode 枚举

**欢迎开始使用 `csweapon_mode` 枚举**

`csweapon_mode` 枚举表示武器的射击模式

**字段**

* **primary\_mode**
  * **描述**: 主模式（通常为左鼠标按钮）
* **secondary\_mode**
  * **描述**: 次模式（通常为右鼠标按钮）

***

苏黎世银云安全 ©

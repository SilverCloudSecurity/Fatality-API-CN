---
description: 欢迎使用 Fatality
---

# user\_t

最后修改时间

25 December 2024

### 简介

`user_t` 类型表示用户的基本信息

***

### 字段

#### avatar

* **只读**
* **类型**: `texture?`
* **描述**: 用户的头像 可能为 `nil`

#### username

* **只读**
* **类型**: `string`
* **描述**: 用户的用户名

***

苏黎世银云安全 ©

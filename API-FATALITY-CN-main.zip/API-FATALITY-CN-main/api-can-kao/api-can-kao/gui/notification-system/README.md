---
description: 欢迎使用 Fatality
---

# Notification System

最后修改时间

25 December 2024

### 简介

`notification_system` 类型表示一个通知系统

***

### 方法

#### add

* **描述**: 将通知添加到列表中
* **参数**:
  * `notif`: `notification` - 通知对象
* **返回值**: 无
* **示例**:

```lua
notif:add(my_notification)
```

***

苏黎世银云安全 ©

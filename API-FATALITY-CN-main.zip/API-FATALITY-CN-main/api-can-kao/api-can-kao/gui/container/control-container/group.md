---
description: 欢迎使用 Fatality
---

# Group

最后修改时间

25 December 2024

### 简介

`group` 类型表示一个分组框控件

***

苏黎世银云安全 ©

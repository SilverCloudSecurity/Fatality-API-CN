---
description: 欢迎使用 Fatality
---

# Control Container

最后修改时间

25 December 2024

### 简介

`control_container` 类型表示一个带有容器的抽象控件

***

苏黎世银云安全 ©
